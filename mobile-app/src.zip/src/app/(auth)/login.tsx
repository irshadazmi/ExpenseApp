import styles from '../../styles/styles'
import React from 'react'
import { Button, View } from 'react-native'

export default function Login() {
	return (
		<View style={styles.container}>
			<Button title="Login"></Button>
			
		</View>
	)
}
